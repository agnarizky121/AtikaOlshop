<style>
    .center {
        text-align: center;
    }
</style>

<!-- Default box -->
<div class="col-sm-12">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Chat dengan pelanggan : <?= $pelanggan->nama_pelanggan; ?></h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i></button>
            </div>
        </div>
        <div class="card-body">
            <div class="direct-chat-messages" id="chatSection">
                <!-- Message. Default to the left -->
                <div class="direct-chat-msg">
                    <div id="pesan">
                        <?php foreach ($chat as $list) {
                            echo "<p>
                            <span><b>$list->nama_user</b></span> - 
                            <span>$list->message</span>
                            </p>";
                        } ?>
                    </div>
                </div>
                <!-- /.direct-chat-text -->
            </div>
            <!-- /.direct-chat-msg -->

            <!-- /.direct-chat-msg -->
            <div class="card-footer">
                <div class="input-group">
                    <input type="text" name="id_penerima" id="id_penerima" value="<?= $pelanggan->id_pelanggan ?>" placeholder="Masukkan Nama ..." class="form-control" hidden>
                    <input type="text" name="id_pengirim" id="id_pengirim" value="<?= $this->session->userdata('id_user'); ?>" placeholder="Masukkan Nama ..." class="form-control" hidden>
                </div>
            </div>

            <div class="card-footer">
                <div class="input-group">
                    <input type="text" name="message" id="message" placeholder="Type Message ..." class="form-control">
                </div>
            </div>

            <div class="card-footer">
                <div class="input-group">
                    <input type="button" class="btn btn-primary btn-block" value="Send" onclick="store()"></input>
                </div>
            </div>
            <!-- /.card-footer-->
        </div>
    </div>
</div>
<!-- /.card -->

<script src="https://js.pusher.com/7.0/pusher.min.js"></script>

<script>
    // Enable pusher logging - don't include this in production
    Pusher.logToConsole = true;

    var pusher = new Pusher('4bc5ccb5eab937c6eff4', {
        cluster: 'ap1',
        encrypted: true
    });

    var channel = pusher.subscribe('my-channel');
    channel.bind('my-event', function(data) {
        addData(data);
    });

    function addData(data) {
        var str = '';
        for (var z in data) {
            str += '<p><span><b>' + data[z].id_pengirim + '</b></span> - <span>' + data[z].message + '</span></p>'
        }
        $('#pesan').html(str);
    }
</script>

<script>
    function store() {
        var value = {
            message: $('#message').val(),
            id_pengirim: $('#id_pengirim').val(),
            id_penerima: $('#id_penerima').val()
        }
        $.ajax({
            url: '<?= site_url(); ?>/chat/store',
            type: 'POST',
            data: value,
            dataType: 'JSON'
        });
    }
</script>