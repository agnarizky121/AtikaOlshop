<?php
require_once('v_head.php');
require_once('v_header_frontend.php');
require_once('v_nav_frontend.php');
require_once('v_content.php');
require_once('v_footer_frontend.php');
