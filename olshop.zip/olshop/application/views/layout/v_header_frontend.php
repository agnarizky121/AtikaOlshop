<body class="hold-transition layout-top-nav">
    <div class="wrapper">