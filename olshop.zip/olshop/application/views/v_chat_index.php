<style>
    .center {
        text-align: center;
    }
</style>


<!-- Default box -->
<div class="col-sm-12">
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Users List</h3>
            <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fas fa-minus"></i></button>
                <button type="button" class="btn btn-tool" data-card-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fas fa-times"></i></button>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <?php foreach ($pelanggan as $key => $value) { ?>
                    <ul class="img-circle">
                        <img class="img-circle" src="<?= base_url('assets/foto/') . $value->foto ?>" width="100" height="100">
                        <div class="center">
                            <a class="users-list-name" style="font-size: 20px;" href="<?= base_url('chat/chat_admin/' . $value->id_pelanggan) ?>"><?= $value->nama_pelanggan ?></a>
                        </div>
                    </ul>
                <?php } ?>
            </div>
        </div>
        <!-- /.card-body -->
        <div class="card-footer">
            Pilih Pelanggan Untuk Mengirim Pesan
        </div>
        <!-- /.card-footer-->
        <!-- /.div col -->
    </div>
</div>
<!-- /.card -->