<?php
defined('BASEPATH') or exit('No direct script access allowed');
require 'vendor/autoload.php';

class Chat extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_admin');
        $this->load->model('m_chat');
        $this->load->model('m_user');
    }

    public function index()
    {
        $data = array(
            'title' => 'Chat User',
            'pelanggan' => $this->m_user->get_pelanggan(),
            'isi' => 'v_chat_index',
        );
        $this->load->view('layout/v_wrapper_backend', $data, FALSE);
    }
    public function chat_admin($id_pelanggan)
    {
        $data = array(
            'title' => 'Chat User',
            'pelanggan' => $this->m_chat->get_pelanggan($id_pelanggan),
            'chat' => $this->m_chat->getmessage_admin($id_pelanggan),
            'isi' => 'v_chat_admin',
        );
        $this->load->view('layout/v_wrapper_backend', $data, FALSE);
    }
    public function store()
    {
        $data = array(
            'name' => $this->input->post('name'),
            'message' => $this->input->post('message'),
            'id_pengirim' => $this->input->post('id_pengirim'),
            'id_penerima' => $this->input->post('id_penerima')
        );

        $options = array(
            'cluster' => 'ap1',
            'encrypted' => true
        );
        $pusher = new Pusher\Pusher(
            '4bc5ccb5eab937c6eff4',
            '7dabdaac66fbd228f19d',
            '1388808',
            $options
        );

        if ($this->db->insert('chat', $data)) {
            $push = $this->db->order_by('id', 'DESC');
            $push = $this->db->get('chat')->result();

            foreach ($push as $key) {
                $data_pusher[] = $key;
            }
            $pusher->trigger('my-channel', 'my-event', $data_pusher);
        }
    }
    public function chat_pelanggan($id_pelanggan)
    {
        $data = array(
            'title' => 'Chat Pelanggan',
            'pelanggan' => $this->m_user->get_pelanggan(),
            'chat' => $this->m_chat->getmessage_pelanggan($id_pelanggan),
        );
        $this->load->view('layout/v_head', $data, FALSE);
        $this->load->view('layout/v_header_frontend', $data, FALSE);
        $this->load->view('layout/v_nav_frontend', $data, FALSE);
        $this->load->view('v_chat_pelanggan', $data, FALSE);
        $this->load->view('layout/v_footer_frontend', $data, FALSE);
    }
}
